#include <stdio.h>
#include <stdlib.h>



int main(void){
	printf("Hola Mundo! smo_routine");
}
