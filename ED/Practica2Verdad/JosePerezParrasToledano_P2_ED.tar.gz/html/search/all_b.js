var searchData=
[
  ['practica_202_2c_20creacion_20de_20una_20lista',['Practica 2, creacion de una Lista',['../index.html',1,'']]],
  ['persona',['Persona',['../classedi_1_1Persona.html#adf50e6e02e0d82db7037f74a6cbd7650',1,'edi::Persona::Persona()'],['../classedi_1_1Persona.html#ac9b88a733b460d61ad145e9c38576eef',1,'edi::Persona::Persona(const char *n, const char *a, const int &amp;d)'],['../classedi_1_1Persona.html#aa73785a179a7230fba804826bff5ab62',1,'edi::Persona::Persona(const Persona &amp;p)']]],
  ['persona',['Persona',['../classedi_1_1Persona.html',1,'edi']]],
  ['persona_2ecpp',['persona.cpp',['../persona_8cpp.html',1,'']]],
  ['persona_2ehpp',['persona.hpp',['../persona_8hpp.html',1,'']]],
  ['previous',['previous',['../classedi_1_1LinkedNode.html#aa3dff6aa75b3f2a61d2f3f63a7e56298',1,'edi::LinkedNode::previous() const '],['../classedi_1_1LinkedNode.html#a3684b801e3616eec2ceaa36082078cf1',1,'edi::LinkedNode::previous()']]]
];
