var searchData=
[
  ['estructuras_20de_20datos',['Estructuras de Datos',['../group__edi.html',1,'']]]
];
