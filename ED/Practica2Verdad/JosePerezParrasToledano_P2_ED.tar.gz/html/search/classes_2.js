var searchData=
[
  ['persona',['Persona',['../classedi_1_1Persona.html',1,'edi']]]
];
