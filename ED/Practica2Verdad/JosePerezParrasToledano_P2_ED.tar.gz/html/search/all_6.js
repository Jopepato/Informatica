var searchData=
[
  ['inserta',['inserta',['../classedi_1_1LinkedList.html#abcf6acdcd3d791ddaf9d49b8a96a6c05',1,'edi::LinkedList::inserta()'],['../classedi_1_1List.html#ae6f16aa8fcd3c6e5b93e6258ac89b335',1,'edi::List::inserta()']]],
  ['isempty',['isEmpty',['../classedi_1_1LinkedList.html#a441bd0ce83f968bfd035898aee35ce07',1,'edi::LinkedList::isEmpty()'],['../classedi_1_1List.html#a99f1769968b6366cebdc529fc208a39c',1,'edi::List::isEmpty()']]],
  ['islast',['isLast',['../classedi_1_1LinkedList.html#a4613b0e1e24af6da544c7925b47d4ade',1,'edi::LinkedList::isLast()'],['../classedi_1_1List.html#aa1cc10f88bb6684fbb523987d51f341a',1,'edi::List::isLast()']]],
  ['isvalid',['isValid',['../classedi_1_1LinkedList.html#ace987043504bd3c24845249fa4b2bdb4',1,'edi::LinkedList::isValid()'],['../classedi_1_1List.html#ab3befc73438a24042d3aa6248e8a0e74',1,'edi::List::isValid()']]],
  ['item',['item',['../classedi_1_1LinkedList.html#a9b964bff1d09e65a96150e8fe4317912',1,'edi::LinkedList::item()'],['../classedi_1_1LinkedNode.html#aac54788675e672b5a9ae85a83890dda8',1,'edi::LinkedNode::item()'],['../classedi_1_1List.html#a7a7923cfc7a3a50f816be51bb49ba698',1,'edi::List::item()']]]
];
