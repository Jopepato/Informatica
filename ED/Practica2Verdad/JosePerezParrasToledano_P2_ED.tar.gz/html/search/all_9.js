var searchData=
[
  ['next',['next',['../classedi_1_1LinkedNode.html#a86170b1d8ac57d1cf1833582ee20d430',1,'edi::LinkedNode::next() const '],['../classedi_1_1LinkedNode.html#a117ff973562fc98074a16b9869f7cfc9',1,'edi::LinkedNode::next()']]],
  ['nombre',['nombre',['../classedi_1_1Persona.html#acc287b52f557e4ae3a6041afef0ca141',1,'edi::Persona::nombre() const '],['../classedi_1_1Persona.html#a3c95142ce2b5c59d3ad2a2b50c5973bd',1,'edi::Persona::nombre(const char *nombre)']]]
];
