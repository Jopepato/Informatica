var searchData=
[
  ['setitem',['setItem',['../classedi_1_1LinkedNode.html#a242bc7398a286f12ea7a1aa964c49415',1,'edi::LinkedNode']]],
  ['setnext',['setNext',['../classedi_1_1LinkedNode.html#aab46adf9737238cad931690cc34ed570',1,'edi::LinkedNode']]],
  ['setprevious',['setPrevious',['../classedi_1_1LinkedNode.html#a5b03ac16df40e909ad528eda6ac80064',1,'edi::LinkedNode']]]
];
