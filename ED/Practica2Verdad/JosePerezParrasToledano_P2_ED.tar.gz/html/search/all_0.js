var searchData=
[
  ['apellido',['apellido',['../classedi_1_1Persona.html#a4d00212fe6e99c3864368a207a191767',1,'edi::Persona::apellido() const '],['../classedi_1_1Persona.html#ad5c9a9471884a19483b20279935efecc',1,'edi::Persona::apellido(const char *apellido)']]],
  ['asignatura',['Asignatura',['../classedi_1_1Asignatura.html',1,'edi']]],
  ['asignatura_2ehpp',['asignatura.hpp',['../asignatura_8hpp.html',1,'']]]
];
