var searchData=
[
  ['edi',['edi',['../namespaceedi.html',1,'edi'],['../group__edi.html',1,'(Namespace global)']]]
];
