var searchData=
[
  ['borrado',['borrado',['../classedi_1_1Persona.html#a3acfc3e07ec3dd168cfc2329a7ada7e4',1,'edi::Persona::borrado() const '],['../classedi_1_1Persona.html#aa119ea26eeac583304547aee16b15c10',1,'edi::Persona::borrado(const char &amp;borrado)']]]
];
