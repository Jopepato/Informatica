var searchData=
[
  ['operator_3c',['operator&lt;',['../classedi_1_1Persona.html#aa83845c0aa706592ca80355e66a4b489',1,'edi::Persona']]],
  ['operator_3c_3d',['operator&lt;=',['../classedi_1_1Persona.html#a47db13059d784b7547a5a092b43f8971',1,'edi::Persona']]],
  ['operator_3d',['operator=',['../classedi_1_1Persona.html#ae57360f67cc87d72b3529eab8fc10bea',1,'edi::Persona']]],
  ['operator_3d_3d',['operator==',['../classedi_1_1Persona.html#a72afb74752956b7fc478bbcf21a58419',1,'edi::Persona']]],
  ['operator_3e',['operator&gt;',['../classedi_1_1Persona.html#af183b841eb8e1b477e5e1391ea04c38e',1,'edi::Persona']]],
  ['operator_3e_3d',['operator&gt;=',['../classedi_1_1Persona.html#a7f3496fa4d87d6bd2c79ccbda98576d6',1,'edi::Persona']]]
];
