var searchData=
[
  ['vectoralista',['VectorALista',['../classedi_1_1Asignatura.html#a646a84dca2c177d3084a551e044f0270',1,'edi::Asignatura']]]
];
