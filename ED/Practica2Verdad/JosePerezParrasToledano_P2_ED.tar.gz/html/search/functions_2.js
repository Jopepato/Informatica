var searchData=
[
  ['deleteposition',['deletePosition',['../classedi_1_1LinkedList.html#a5bf790b49f73467d0364656be3a2e2d6',1,'edi::LinkedList::deletePosition()'],['../classedi_1_1List.html#a0b73c2aa55f28edd4908182fa34aea5d',1,'edi::List::deletePosition()']]],
  ['dni',['dni',['../classedi_1_1Persona.html#a76626aaa10e27c4f860a450d78d96e18',1,'edi::Persona::dni() const '],['../classedi_1_1Persona.html#aff4b82748061395c6c169c298fca89b3',1,'edi::Persona::dni(const int &amp;dni)']]]
];
