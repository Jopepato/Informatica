var searchData=
[
  ['asignatura',['Asignatura',['../classedi_1_1Asignatura.html',1,'edi']]]
];
