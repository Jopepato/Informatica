var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classedi_1_1Persona.html#a3b4f83a6d8b613e47e14d9982c0d8354',1,'edi::Persona']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classedi_1_1Persona.html#a0b6ab6dd403b11efdc800f537e911763',1,'edi::Persona']]]
];
