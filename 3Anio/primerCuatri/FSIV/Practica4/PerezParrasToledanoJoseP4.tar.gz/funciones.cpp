#include "funciones.hpp"

void help(){

	cout << "Ayuda con los comandos: " << endl;
	cout << "-h: Muestra la ayuda del programa" << endl;
	cout << "-i nombreVideo: Video que se va a cargar para el programa" << endl;
	cout << "-o nombreVideoSalida: Video de salida con fondo quitado" << endl;
	cout << "-t valor: Valor para la diferencia entre fotogramas" << endl;
}