/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package profesor;

/**
 *
 * @author i32petoj
 */
public class Profesor extends Persona {

    String universidad_;
    int id_;
    
    //Constructor
    public void Profesor(){
        
    }
    
    //Setters
    public void setUniversidad(String universidad){
        universidad_ = universidad;
    }
    public void setId(int id){
        id_ = id;
    }
    
    //Getters
    public String getUniversidad(){
        return universidad_;
    }
    public int getId(){
        return id_;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Profesor profe = new Profesor();
        
        profe.setEdad(25);
        profe.setNombre("Bartolin");
        profe.setApellidos("Perez");
        profe.setId(1);
        profe.setUniversidad("Uco");
        
        //Imprimimos
        System.out.println("El profesor " + profe.getNombre() + " " + profe.getApellidos() + " con edad " + profe.getEdad() + " trabaja en la universidad " + profe.getUniversidad() + "y tiene un id de profesor " + profe.getId());
        
        
    }
    
}
