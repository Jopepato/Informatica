/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package profesor;

/**
 *
 * @author i32petoj
 */
public class Persona {
    private String nombre_;
    private String apellidos_;
    private int edad_;
    
    //Constructor
    public void Persona(){
        
    }
    
    //Setters
    public void setNombre(String nombre){
        nombre_ = nombre;
    }
    public void setApellidos(String apellidos){
        apellidos_ = apellidos;
    }
    public void setEdad(int edad){
        edad_ = edad;
    }
    
    //Getters
    
    public String getNombre(){
        return nombre_;
    }
    
    public String getApellidos(){
        return apellidos_;
    }
    
    public int getEdad(){
        return edad_;
    }
}

